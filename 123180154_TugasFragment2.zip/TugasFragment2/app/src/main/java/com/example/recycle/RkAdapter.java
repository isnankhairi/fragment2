package com.example.recycle;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class RkAdapter extends RecyclerView.Adapter<RkAdapter.ListViewHolder> {
    private Context context;
    private ArrayList<Rk> rkModels;

    public RkAdapter(ArrayList<Rk> rkModels, Context context) {
        this.context = context;
        this.rkModels = rkModels;
    }
    @NonNull
    @Override
    public RkAdapter.ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rk, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        Glide.with(holder.itemView.getContext())
                .load(getRkModels().get(position).getLogork())
                .apply(new RequestOptions().override(75,75))
                .into(holder.logork);
        holder.namark.setText(getRkModels().get(position).getNamark());
        holder.desrk.setText(getRkModels().get(position).getDesrk());
        holder.details.setOnClickListener(v -> {
            Intent moveIntent = new Intent(context ,DetailRk.class);
            moveIntent.putExtra("namark",getRkModels().get(position).getNamark());
            moveIntent.putExtra("desrk",getRkModels().get(position).getDesrk());
            moveIntent.putExtra("logork",getRkModels().get(position).getLogork());
            context.startActivity(moveIntent);
        });
    }

    @Override
    public int getItemCount() {
        return getRkModels().size();
    }

    public ArrayList<Rk> getRkModels() {return rkModels;}

    public static class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView logork;
        TextView namark;
        TextView desrk;
        Button details;

        ListViewHolder(View itemview) {
            super(itemview);
            logork = itemview.findViewById(R.id.logo);
            namark = itemview.findViewById(R.id.namark);
            desrk = itemview.findViewById(R.id.desrk);
            details = itemview.findViewById(R.id.btn_detail);
        }
    }
}
