package com.example.recycle;

public class Rk {
    private String namark;
    private String desrk;
    private int logork;

    public String getNamark() {
        return namark;
    }

    public void setNamark(String namark) { this.namark = namark; }

    public String getDesrk() {
        return desrk;
    }

    public void setDesrk(String desrk) {
        this.desrk = desrk;
    }

    public int getLogork() { return logork; }

    public void setLogork(int logork) {
        this.logork = logork;
    }
}
