package com.example.recycle;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailRk extends AppCompatActivity {
    ImageView dtlogo;
    TextView dtnama, dtdeskripsi;

    String namark;
    String desrk;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_rk);

        dtlogo = findViewById(R.id.logo_detail);
        dtnama = findViewById(R.id.nama_detail);
        dtdeskripsi = findViewById(R.id.deskripsi_detail);

        namark = getIntent().getStringExtra("namark");
        desrk = getIntent().getStringExtra("desrk");

        dtnama.setText(namark);
        dtdeskripsi.setText(desrk);
        Glide.with(this).load(getIntent().getIntExtra("logork", 0)).into(dtlogo);
    }
}
